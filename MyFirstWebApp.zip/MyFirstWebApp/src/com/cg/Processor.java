package com.cg;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Processor
 */
@WebServlet("/Processor")
public class Processor extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
   
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	response.setContentType("text/html");
	PrintWriter out=response.getWriter();
	
	Enumeration<String> names=request.getParameterNames();
	while(names.hasMoreElements()) {
		out.println(names.nextElement());
		out.println("<br/>");
	}
	
	
	String firstname=request.getParameter("fname");
	String lastname=request.getParameter("lname");
	String userId=request.getParameter("userId");
	String password=request.getParameter("password");
	String gender=request.getParameter("gender");
	String city=request.getParameter("city");
	
	String[] skills=request.getParameterValues("skills");
	StringBuilder sb=new StringBuilder();
	for(String skill:skills) {
		sb.append(skill+",");
	}
	
	String comments=request.getParameter("comments");
	
	out.println("<table border='1'>");
	out.println("<tr>");
	out.println("<td>First Name</td>");
	out.println("<td>"+firstname+"</td>");
	out.println("</tr>");
	out.println("<td>Last Name</td>");
	out.println("<td>"+lastname+"</td>");
	out.println("</tr>");
	out.println("<td>User Id</td>");
	out.println("<td>"+userId+"</td>");
	out.println("</tr>");
	out.println("<td>Password</td>");
	out.println("<td>"+password+"</td>");
	out.println("</tr>");
	out.println("<td>Gender</td>");
	out.println("<td>"+gender+"</td>");
	out.println("</tr>");
	out.println("<td>City</td>");
	out.println("<td>"+city+"</td>");
	out.println("</tr>");
	out.println("<td>Skills</td>");
	out.println("<td>"+sb.toString()+"</td>");
	out.println("</tr>");
	out.println("<td>Comments</td>");
	out.println("<td>"+comments+"</td>");
	out.println("</tr>");
	out.println("</table>");
	out.println("<br/>");
    out.println(request.getMethod());

    out.println("<br/>");
    out.println(request.getPathInfo());
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
