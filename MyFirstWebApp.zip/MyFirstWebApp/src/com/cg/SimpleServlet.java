package com.cg;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SimpleServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		ServletConfig config = getServletConfig();
		String name = config.getInitParameter("userName");
		String city = config.getInitParameter("city");
		ServletContext context = getServletContext();
		String comp = context.getInitParameter("company");

		out.println("<html>");
		out.println("<head><title>MyApp</title></head>");
		out.println("<body>");
		out.println("<h1>Hello from Simple Servlet</h1>");
		out.println("<h3>Welcome " + name + " You are from " + city + "</h3>");
		out.println("<h3>your company is " + comp + " </h3>");
		out.println("</body></html>");
	}

}
