package com.cg;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FirstServlet
 */
@WebServlet(urlPatterns = ("/FirstServlet"), initParams = { @WebInitParam(name = "userName", value = "kumar"),
		@WebInitParam(name = "city", value = "Kakinada"), }, loadOnStartup = 1)
public class FirstServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		out.println(request.getServerName());
		out.println("<br/>");
		out.println(request.getServerPort());
		out.println("<br/>");
		out.println(getServletContext().getServerInfo());
		out.println("<br/>");
		out.println(request.getRemoteHost());
		out.println("<br/>");
		out.println(request.getRemoteAddr());
		request.setAttribute("name", "surath siva");
		String name=(String) request.getAttribute("name");
		out.println("<br/>");
		out.println("Name "+name);
		out.println(request.getRemoteUser());
		
		
		String query=request.getQueryString();
		out.println("<br/>");
		out.println(query);
		 name=request.getParameter("name");
		 int age= Integer.parseInt(request.getParameter("age"));
		 out.println("<br/>");
	     out.println(name+" "+age);
	     out.println("<br/>");
	     out.println();


	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
