package com.cg;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DispalyProductInfo
 */
@WebServlet("/DispalyProductInfo")
public class DispalyProductInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
        PrintWriter out=response.getWriter();
		String productName=request.getParameter("prodName");
		double price=Double.parseDouble(request.getParameter("prodPrice"));
		int qty= Integer.parseInt(request.getParameter("prodQty"));
		out.println("Product data entered....<br/>");
		out.println("Product Name :"+productName+" Price "+price+" Quantity "+qty);
		String shop= (String) request.getAttribute("shopName");
		String mail= (String) request.getAttribute("mail");
		out.println("<br/>");
		out.println("Shop Name :"+shop+"<br/>");
		out.println("Mail :"+mail);
		
	}

}
