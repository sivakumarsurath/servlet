package com.cg;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/authenticate")
public class AuthenticateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/*
		 * String userId=request.getParameter("uid"); String
		 * password=request.getParameter("pwd");
		 * 
		 * if(userId.equals("siva") && password.equals("ATP")) {
		 * response.sendRedirect("success.html");
		 * 
		 * } else { response.sendRedirect("error.html");
		 * 
		 * }
		 */
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<h1> Welcome to AuthenticationServlet </h1>");
		String userId = request.getParameter("uid");
		Cookie cookie = new Cookie("userId", userId);
		cookie.setMaxAge(60);
		response.addCookie(cookie);
		out.println("Cookie Written");
	}

}
