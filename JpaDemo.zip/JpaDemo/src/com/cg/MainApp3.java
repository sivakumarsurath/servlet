package com.cg;

import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

public class MainApp3 {
	public static void main(String[] args) {
		EntityManagerFactory fac = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = fac.createEntityManager();
		User user = new User();
		user.setName("sivakumarsurath");
		Vehicle vehicle = new Vehicle();
		vehicle.setVehicleName("lamborghini");
		user.setVehicle(vehicle);

		vehicle.setUser(user);
		em.getTransaction().begin();

		em.persist(user);
		em.persist(vehicle);
		em.getTransaction().commit();

		/*
		 * TypedQuery<Employee1> query= em.createNamedQuery("getEmployeeByGender",
		 * Employee1.class); 
		 * query.setParameter("gen", "Male");
		 * 
		 * 
		 * List<Employee1> employees= query.getResultList(); 
		 * for(Employee1 employee:
		 * employees) { System.out.println(employee); }
		 */

		// Scanner sc = new Scanner(System.in);
		// System.out.println("Enter gender");
		// String gender=sc.nextLine();
		/*
		 * System.out.println("Enter EmployeeId"); 
		 * int empId = sc.nextInt();
		 * System.out.println("Enter Age"); 
		 * int age = sc.nextInt();
		 */
		/*
		 * System.out.println("Enter Salary"); 
		 * double salary = sc.nextDouble();
		 */

		/*
		 * //positional parameter ? 
		 * Query query =
		 * em.createQuery("update Employee1 set age=?,salary=? where id=?");
		 * query.setParameter(1, age); 
		 * query.setParameter(2, salary);
		 * query.setParameter(3, empId); 
		 * em.getTransaction().begin(); 
		 * int
		 * result=query.executeUpdate(); 
		 * em.getTransaction().commit();
		 * System.out.println(result+ "row(s) updated");
		 * 
		 */
		// named parameter
		// for updating
		/*
		 * Query query
		 * =em.createQuery("update Employee1 set age=:age,salary=:sal where id=:eno");
		 * query.setParameter("age", age); 
		 * query.setParameter("sal", salary);
		 * query.setParameter("eno", empId); 
		 * em.getTransaction().begin(); int
		 * result=query.executeUpdate(); 
		 * em.getTransaction().commit();
		 * System.out.println(result+ "row(s) updated");
		 */

		// for deleting based on salary constrain
		/*
		 * Query query = em.createQuery("delete from Employee1 where salary<:sal");
		 * query.setParameter("sal", salary); em.getTransaction().begin(); int result =
		 * query.executeUpdate(); em.getTransaction().commit();
		 * System.out.println(result + "row(s) deleted");
		 */

		// TypedQuery<Employee1> query=em.createQuery("from Employee1",
		// Employee1.class);
		// List<Employee1> employees=query.getResultList();
		// for(Employee1 employee: employees) {
		// System.out.println(employee);

		// TypedQuery<Employee1> query=em.createQuery("from Employee1 where gender=?",
		// Employee1.class);
		// query.setParameter(1, gender);
		// TypedQuery<Employee1> query=em.createQuery("select emp from Employee1 emp
		// where emp.gender=:gen", Employee1.class);
		// TypedQuery<Employee1> query=em.createQuery("from Employee1 where
		// gender=:gen", Employee1.class);

		// query.setParameter("gen", gender);

		// List<Employee1> employees=query.getResultList();
		// for(Employee1 employee: employees) {
		// System.out.println(employee);
		// }
		/*
		 * TypedQuery<Employee1> query=em.createQuery("from Employee1 where id=:eno",
		 * Employee1.class);
		 * 
		 * query.setParameter("eno",empId); Employee1 employee =query.getSingleResult();
		 * System.out.println(employee);
		 */

	}

}
