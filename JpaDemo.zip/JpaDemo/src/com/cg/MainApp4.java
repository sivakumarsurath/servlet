package com.cg;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class MainApp4 {

	public static void main(String[] args) {
		EntityManagerFactory fac = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = fac.createEntityManager();
		Vehicle1 vehicle=new Vehicle1();
		vehicle.setVehicleName("Car");
		vehicle.setLicenseNumber("KA 01 2345");
		
		
		TwoWheeler tw=new TwoWheeler();
		tw.setVehicleName("duke");
	    tw.setLicenseNumber("KL-23-1997");
	    tw.setSteeringHandle("Bike Steering Handle");
	    
	    FourWheeler fw=new FourWheeler();
	    fw.setVehicleName("Lambo");
	    fw.setLicenseNumber("AP-53 1997");
	    fw.setSteeringWheel("Lambo Steering Wheel");
	    
	    em.getTransaction().begin();
	    em.persist(vehicle);
	    em.persist(tw);
	    em.persist(fw);
	    em.getTransaction().commit();
	    
	    	
	}
}
