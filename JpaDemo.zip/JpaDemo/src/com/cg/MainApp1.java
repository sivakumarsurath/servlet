package com.cg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class MainApp1 {
	public static void main(String[] args) {

		String url = "jdbc:oracle:thin:@localhost:1521:xe";// url for connecting db
		Scanner scan = new Scanner(System.in);
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection(url, "ssurath", "root");
			Employee1 emp = new Employee1();
			System.out.println("enter id: ");
			emp.setId(Integer.parseInt(scan.nextLine()));
			System.out.println("enter name: ");
			emp.setName(scan.nextLine());
			System.out.println("enter gender: ");
			emp.setGender(scan.nextLine());
			System.out.println("enter Age: ");
			emp.setAge(Integer.parseInt(scan.nextLine()));
			System.out.println("enter salary: ");
			emp.setSalary(Double.parseDouble(scan.nextLine()));
			PreparedStatement stat = con.prepareStatement("insert into employee1 values(?,?,?,?,?)");
			stat.setInt(1, emp.getId());
			stat.setString(2, emp.getName());
			stat.setString(3, emp.getGender());
			stat.setInt(4, emp.getAge());
			stat.setDouble(5, emp.getSalary());

			int result = stat.executeUpdate();
			System.out.println(result + " row(s) inserted into the database");

		} catch (SQLException e) {

			e.printStackTrace();

		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		}

	}
}