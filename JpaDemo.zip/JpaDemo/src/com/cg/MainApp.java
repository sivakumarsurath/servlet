package com.cg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class MainApp {
	public static void main(String[] args) {
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");// oracledriver is class
			try {
				Connection con = DriverManager.getConnection(url, "ssurath", "root");
				Statement stat = con.createStatement();
				ResultSet rs = stat.executeQuery("select * from employee1");
				List<Employee1> employees = new ArrayList<>();
				while (rs.next()) {
					Employee1 emp = new Employee1();
					emp.setId(rs.getInt(1));
					emp.setName(rs.getString(2));
					emp.setGender(rs.getString(3));
					emp.setAge(rs.getInt("age"));
					emp.setSalary(rs.getDouble(5));
					employees.add(emp);
				}
				for (Employee1 employee : employees) {
					System.out.println(employee);
				}

			} catch (SQLException e) {

				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		}
	}

}
