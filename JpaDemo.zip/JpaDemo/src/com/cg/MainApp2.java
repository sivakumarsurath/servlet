package com.cg;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class MainApp2 {
	public static void main(String[] args) {

		//Employee1 emp = new Employee1(1009, "Durga", "Male", 23, 35000);
		Employee1 emp=new Employee1();
		emp.setName("alu");
		emp.setGender("Female");
		emp.setAge(21);
		
		emp.setSalary(50000);
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();

		/*
		 * To enter the data into sql 
		 * em.getTransaction().begin(); 
		 * em.persist(emp);
		 * em.getTransaction().commit(); 
		 * System.out.println("Data Saved...");
		 */

		/*
		 * locate the id 
		 * Scanner scan=new Scanner(System.in);
		 * System.out.println("enter EmployeeId");
		 *  int empId=scan.nextInt();
		 *   Employee1
		 * e=em.find(Employee1.class, empId); 
		 * System.out.println(e);
		 */

		/*
		 * Delete operation 
		 * Scanner scan=new Scanner(System.in);
		 * System.out.println("enter Employee Id");
		 *  int empId=scan.nextInt();
		 * em.getTransaction().begin();
		 *  Employee1 e=em.find(Employee1.class, empId);
		 * em.remove(e); 
		 * em.getTransaction().commit();
		 	System.out.println("Employee withId " + empId + " removed from datbase");
		 */

		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Employee Id");
		int empId = scan.nextInt();
		em.getTransaction().begin();
		Employee1 e = em.find(Employee1.class, empId);
		//em.remove(e);//for removing data
		//for setting the data
		//e.setAge(21);
		//e.setSalary(75000);
		em.getTransaction().commit();
		System.out.println("Employee withId " + empId + " updated in the datbase");
	}

}
