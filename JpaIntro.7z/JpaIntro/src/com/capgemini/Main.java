package com.capgemini;

import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {

	public static void main(String[] args) {
		Author1 author1 = new Author1(1001, "siva", "kumar", "surath", 9999);
		Author1 author2 = new Author1(1002, "durga", "prasad", "surath", 8888);

		EntityManagerFactory fac = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = fac.createEntityManager();
		em.getTransaction().begin();
		

		em.persist(author1);
		em.persist(author2);
		em.getTransaction().commit();

		Scanner scan = new Scanner(System.in);
		// for updating
		System.out.println("enter Employee Id to update");
		int Id = scan.nextInt();
		em.getTransaction().begin();
		Author1 author = em.find(Author1.class, Id);
		author.setFirstName("veerendra");
		author.setLastName("yandamuri");
		author.setMiddleName("nadh");
		author.setPhoneNo(96664);
		em.getTransaction().commit();
		System.out.println("Author Updated" + Id);
		// for delete
		System.out.println("enter Author to delete");
		int authId = scan.nextInt();
		em.getTransaction().begin();
		Author1 auth = em.find(Author1.class, authId);
		em.remove(auth);
		em.getTransaction().commit();
		System.out.println("Author  deleted" + authId);
		// to read
		System.out.println("enter AuthId to read");
		int authId1 = scan.nextInt();
		Author1 auth1 = em.find(Author1.class, authId1);
		System.out.println(auth1);
	}
}
