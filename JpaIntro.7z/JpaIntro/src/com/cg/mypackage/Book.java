package com.cg.mypackage;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Book {
	@Id
	@GeneratedValue
	private int ISBN;
	private String Title;
	private double Price;
	public int getISBN() {
		return ISBN;
	}
	public void setISBN(int iSBN) {
		ISBN = iSBN;
	}
	public String getTitle() {
		return Title;
	}
	public void setTitle(String title) {
		Title = title;
	}
	public double getPrice() {
		return Price;
	}
	public void setPrice(double price) {
		Price = price;
	}
	@Override
	public String toString() {
		return "Book [ISBN=" + ISBN + ", Title=" + Title + ", Price=" + Price + "]";
	}
	public void add(Book book) {
		// TODO Auto-generated method stub
		
	}
	
	
	
	
}
