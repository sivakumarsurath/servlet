package com.cg.mypackage;

import java.util.List;
import java.util.Scanner;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.capgemini.Author1;
import com.cg.Author;


public class Main1 {
	public static void main(String[] args) {
		
		EntityManagerFactory fac = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = fac.createEntityManager();
	
		Author2 author=new Author2();
		
		author.setName("puri");
	    Book book=new Book();
	    book.setTitle("NaIstam");
	    book.setPrice(900);
	    
	    Book book1=new Book();
	    book1.setTitle("Evaru");
	    book1.setPrice(1000);
	    author.getBook().add(book);
	    author.getBook().add(book1);
	    
	    em.getTransaction().begin();
	    
	    em.persist(author);
	    
	    em.getTransaction().commit();
	   
	    TypedQuery<Book> query1=em.createQuery("select  book from Author2 author join author.book book where author.name=?",Book.class);
	    query1.setParameter(1, "puri");
	   List<Book> authors=query1.getResultList();
	    for(Book author1:authors) {
	          System.out.println(author1);
	  
	    }
		
	}

}
